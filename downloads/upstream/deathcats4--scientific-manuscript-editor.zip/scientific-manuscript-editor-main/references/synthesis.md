# Title, Abstract, and Conclusion synthesis

Use for Title, Abstract, Conclusion, or coordinated contribution framing. These
components are new representations of an established scientific argument under
tighter information constraints; they are not copied or mechanically shortened
parts of the body.

## Shared compression principle

Preserve the smallest scientific model that allows the reader to understand the
contribution accurately:

- the problem or motivation that defines the work;
- what the study did or made possible;
- the decisive finding or evidence;
- the main supported understanding;
- any condition or boundary that changes its meaning.

These are diagnostic roles to select for the component, not five required
slots or a prescribed order. A title, abstract, and conclusion have different
information needs; honor any author-requested or journal-required structure.

Compression may remove secondary detail, repeated context, and procedures that
do not affect interpretation. It must not remove a qualifier that carries
scientific meaning or strengthen `supports` into `demonstrates`, association
into causation, or a possible mechanism into a confirmed one.

State the contribution through the concrete change the study makes—what it
identifies, distinguishes, constrains, connects, explains, or enables. Generic
formulas such as providing some insight or a possible reference leave the
scientific content unspecified; state the concrete change directly.

## Abstract

An Abstract should let a reader who has not seen the paper form a correct
minimal model of the study: why the question matters, what was done, what was
found, and what the work establishes or enables. Keep the contribution at its
supported scale rather than requiring a claim of wider significance.

Choose emphasis from the actual contribution. A discovery-centred Abstract may
move from problem to key observation and its meaning; a mechanism-centred one
may move from unresolved process to decisive evidence and explanation; a
method- or resource-centred one may show the previous limitation, new
capability, and science it enables. Hybrids are valid.

Select results rather than listing them. Include method detail when it is
needed to understand credibility or the contribution. Express a supported
implication where it helps the reader understand the work; the abstract can
also end on its decisive finding or a defining condition when that completes
the account. Do not append an importance sentence solely to fill an ending slot.

## Conclusion

A Conclusion answers: after considering the complete argument, what should the
reader now understand? It may synthesize findings, state a supported mechanism
or model, define a boundary, refine theory, or express a justified application.

Keep the Conclusion focused on synthesis: carry forward the established
certainty and scope, while leaving new evidence, a reopened Discussion, and
generic future work outside this component.

## Title

A title is the most compressed representation of the paper's central
contribution. Emphasize the scientific object and the contribution that the
paper actually earns: discovery, mechanism, framework, capability, method, or
resource.

Use causal, universal, and novelty language at the level established by the body.
Keep a defining condition when removing it would materially broaden the claim.
Replace vague importance claims, method lists without scientific meaning, and
jargon that hides the contribution with concrete scientific content.

## Cross-component check

Verify that:

- the Title stays within the scope of the Abstract and body;
- the Abstract's key findings appear in Results;
- its interpretation is developed in Discussion;
- the Conclusion introduces no new evidence or mechanism;
- repeated numbers, objects, conditions, and claim strengths agree across all
  supplied components.
