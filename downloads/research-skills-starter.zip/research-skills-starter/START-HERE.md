# 10 个科研 Skills 入门合集

下载 → 解压 → 选择 skills/ 中的完整技能目录 → 导入或复制到 Agent 的技能目录 → 提交任务。

每个技能目录包含 SKILL.md、SOURCE.md 和 references/，请一起保留。
本地 Codex 当前项目可使用 .agents/skills/；本地 Claude Code 可使用 .claude/skills/。
有导入界面的产品按界面要求逐个选择技能，合集 ZIP 不一定能直接导入。

示例：使用 academic-proofreading，只修正下面英文段落的拼写和语法错误，不润色。

没有导入功能时，可以复制 SKILL.md 正文作为任务要求，原始提示词在各技能的 references/source-prompts.md 中。
文献检索需要 Agent 自带联网能力；绘图技能默认输出绘图说明与提示词。

官方目录说明：https://learn.chatgpt.com/docs/build-skills
Claude Code：https://code.claude.com/docs/en/skills
