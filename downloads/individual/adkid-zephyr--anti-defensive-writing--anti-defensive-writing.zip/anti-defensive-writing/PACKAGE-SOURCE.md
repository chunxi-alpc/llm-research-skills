# 来源与打包说明

原项目：[Adkid-Zephyr/anti-defensive-writing-Skill](https://github.com/Adkid-Zephyr/anti-defensive-writing-Skill)。

获取日期：2026-11-05，分支：main。

原表记录：R045。许可：MIT。

打包内容：skills/anti-defensive-writing 的完整文件。原技能正文未改写；增加本说明并携带原许可。依赖及具体安装方法以原项目为准。

同名技能按作者分包，请在不同项目选择版本或使用客户端支持的命名空间，不要合并到一个安装目录。
