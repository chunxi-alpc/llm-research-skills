# 论文阅读与多论文对比：原表提示词与经验

此文件保留来源材料，供需要时查阅。当前技能的执行要求以 SKILL.md 为准；原表中的价格、额度、模型版本和个人评价是填写时的记录。

## R001 · NotebookLM：多论文比较

原 CSV 逻辑记录：2。

### 原始入口

````text
https://notebooklm.google.com/
````

### 原始使用方法或提示词

````text
输入下列提示词：“Compare these 5 papers and identify research gaps”，并选择或上传所需要检索的论文
````

### 原表使用经验

````text
多论文联合分析，多文档 reasoning 很强，很适合写 related work，形成自己领域的文档库
````


## R006 · 腾讯 ima：论文知识库

原 CSV 逻辑记录：7。

### 原始入口

````text
IMAhttps://ima.qq.com/
````

### 原始使用方法或提示词

````text
搜索腾讯ima,下载客户端后点击知识库，在知识库中选择新建知识库，并上传已经下载的论文文献
````

### 原表使用经验

````text
多论文多文档联合分析，可以选择不同模型，可以配合related work写作以及论文综述写作
````


## R007 · 智谱清言：论文精读

原 CSV 逻辑记录：8。

### 原始入口

````text
智谱清言https://chatglm.cn
````

### 原始使用方法或提示词

````text
搜索智谱清言，点击阅读论文，上传论文的PDF或word文件，即可整理出对应论文大纲。也可以输入prompt ,诸如“概括文献的优缺点”“总结后续研究拓展方向”等。
````

### 原表使用经验

````text
擅长总结文献解决的问题，总体架构从输入到输出的流程总结。并且界面友好，做到边阅读边分析，适合精读论文。
````


## R008 · WorkBuddy：检索并整理论文

原 CSV 逻辑记录：9。

### 原始入口

````text
workbuddyhttps://www.codebuddy.cn/
````

### 原始使用方法或提示词

````text
在workbuddy中的skill中选择academic research和agent browser，然后在交互页面中输入你的要求，例如“我需要一个XXX领域的paper，最好使用了XXXX技术，发表时间在xxxx年的A会上，请你帮我检索一下，并将符合的paper下载到XXXX，并整理一个总的大纲给我”
````

### 原表使用经验

````text
可以快速找文献，以目前使用经历来看，找到的文献都是真实准确的，其中还有很多其他skill可供使用，但是做PPT之类的功能比较差
````


## R009 · DeepSeek / Kimi：论文总结与讨论

原 CSV 逻辑记录：10。

### 原始入口

````text
deepseek（https://chat.deepseek.com/）、kimi（https://www.kimi.com/）等大模型
````

### 原始使用方法或提示词

````text
上传论文文件，将具体需求告诉大模型，可以要求其提供原文中的具体依据（提升模型总结的准确性）
````

### 原表使用经验

````text
可多次免费上传文档，不限制单日上传文档数，适合快速提炼文章内容、辅助筛选文章，也可以对比少量文章之间的方法
````


## R041 · Zotero + zotero-gpt

原 CSV 逻辑记录：55。

### 原始入口

````text
Zotero + zotero-gpt（https://github.com/MuiseDestiny/zotero-gpt）
````

### 原始使用方法或提示词

````text
文献管理、PDF 问答、笔记整理、选中文本解释、引用辅助
````
