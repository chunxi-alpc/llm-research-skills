# 来源与打包说明

原项目：[multica-ai/andrej-karpathy-skills](https://github.com/multica-ai/andrej-karpathy-skills)。

获取日期：2026-11-05，分支：main。

原表记录：R022。许可：MIT (README declaration)。

打包内容：skills/karpathy-guidelines 的完整文件。原技能正文未改写；增加本说明并携带原许可。依赖及具体安装方法以原项目为准。

上游 README 的原许可声明如下（获取版本没有独立 LICENSE 文件）：

## License

MIT
