# 来源与打包说明

原项目：[deathcats4/scientific-manuscript-editor](https://github.com/deathcats4/scientific-manuscript-editor)。

获取日期：2026-11-05，分支：main。

原表记录：R043。许可：MIT。

打包内容：. 的完整文件。原技能正文未改写；增加本说明并携带原许可。依赖及具体安装方法以原项目为准。
